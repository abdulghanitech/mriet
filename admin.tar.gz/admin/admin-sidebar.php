<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="../images/user.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
                <p><?php 
                  $name = $_SESSION['username'];
                  echo $name;
                  ?></p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- search form (Optional) -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu">
        <li class="header">ADMINISTRATION</li>
        <!-- Optionally, you can add icons to the links -->
        <li id="sidebar-dashboard"><a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li id="sidebar-configuration"><a href="configuration.php"><i class="fa fa-wrench"></i> <span>Configuration</span></a></li>
        <li class="treeview" id="sidebar-apps">
          <a href="#"><i class="fa fa-cubes"></i> <span>Apps</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="apps-list.php">Apps List</a></li>
            <li><a href="app-new.php">Create New App</a></li>
          </ul>
        </li>
         <li class="treeview" id="sidebar-widgets">
          <a href="#"><i class="fa fa-cogs"></i> <span>Widgets</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="widgets-list.php">Widgets List</a></li>
            <li><a href="widget-new.php">Add New Widget</a></li>
          </ul>
        </li>
        <li class="treeview" id="sidebar-pages">
          <a href="#"><i class="fa fa-file"></i> <span>Pages</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages-list.php">Pages List</a></li>
            <li><a href="page-new.php">Add New Page</a></li>
          </ul>
        </li>
        
            <li class="treeview" id="sidebar-appearance">
          <a href="#"><i class="fa fa-eye"></i> <span>Appearance</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="color-schemes.php">Color Schemes</a></li>
            <li><a href="featuredapps.php">Featured Apps</a></li>
          </ul>
        </li>

        <li><a href="#"><i class="fa fa-user"></i> <span>Admin Profile</span></a></li>

      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>