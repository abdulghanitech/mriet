<?php
//these file handles insertion of details into basicappdetails from the first form
//Setting root
$root = realpath($_SERVER["DOCUMENT_ROOT"]);

// Fetching Values From URL
$appurl = $_POST["appurl"];
$apptitle = $_POST["apptitle"];
$appdesc = $_POST["appdesc"];


include "ajax_image_upload.php";

include "../database.php";

//handling file

if ($_POST["appurl"]!=''&&$_POST["apptitle"]!=''&&$_POST["appdesc"]!=''&&$imageurl!='')
 {
	

$query = "INSERT INTO basicappdetails(appurl, apptitle, appdesc, appimage) VALUES ('$appurl','$apptitle', '$appdesc','$imageurl')"; //Insert Query

	if(mysqli_query($conn,$query)){

	//echo "Form Submitted Succesfully";
		$response_array['status'] = 'success';
		header('Content-type: application/json');
        echo json_encode($response_array);

	}
	else {
		
	//echo "Please Enter Valid Details";
	    $response_array['status'] = 'error';
		header('Content-type: application/json');
        echo json_encode($response_array);
	}

}



?>