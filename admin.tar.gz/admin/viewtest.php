<?php session_start(); 
if (!$_SESSION['username'])  
{  
    header('location: index.php');  
    exit;  
}?>
<!DOCTYPE html>
<html>
<head>
	<title>iHeroQuizz | View Test - Admin Panel</title>
	
	


<?php 
$root = realpath($_SERVER["DOCUMENT_ROOT"]);

include "$root/header.php";



		include "db.php";
		mysqli_set_charset($conn, "utf8");



		

		$sql="SELECT testname,testurl,published_status FROM dashboard WHERE published_status='yes' ORDER BY id DESC";

		$result=mysqli_query($conn,$sql);

		if(mysqli_num_rows($result) > 0){ 
?>
<br><br>
<div class="container-fluid">
	<div class="row">

		<center><h2>View Tests</h2></center>

				
				        <?php 
				  $i=1;
				        while($row=mysqli_fetch_assoc($result))
					{
						
						/*echo "<div class=\"col-md-6\">";

						echo "<h3>".$row["testname"]."</h3>";
						echo "<a href=\"".$row["testurl"]."\">";
						echo "<img src=\"".$row["testurl"]."intro.jpg\" class=\"img-responsive\"></a><br>";
						
						echo "</div>";*/



						echo "<div class=\"col-sm-6 col-md-4\">";
					    echo "<div class=\"panel panel-primary\">";
					          echo "<div class=\"panel-body\">";
					          echo "<a href=\"".$row["testurl"]."\">";
					          echo "<img src=\"".$row["testurl"]."intro.jpg\" class=\"img-responsive\"></a></div>";
					         echo "<div class=\"panel-footer\">";
					         echo "<b>".$row["testname"]."</b>";
					         echo "</div></div></div>";
					      
						$i++;

					}
				}



						mysqli_close($conn);


						?>

				    
				 

	</div>

	
</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<?php include "$root/footer.php"; ?>