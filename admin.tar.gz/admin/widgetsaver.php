<?php
//Saving the widgets
//Setting root
$root = realpath($_SERVER["DOCUMENT_ROOT"]);
include "../database.php";

$widgetname = mysqli_real_escape_string($conn, $_POST["widgetname"]);
$widgetplacement = mysqli_real_escape_string($conn, $_POST["widgetplacement"]);
$widgetcontent = $_POST["widgetcontent"];
//base64 encoding widget content
$widgetcontent = base64_encode($widgetcontent);


//echo "in the widgetsaver";
/*echo $widgetcontent;
echo $widgetname;
echo $widgetplacement;*/

//check if they are not null

if($widgetcontent!=''&&$widgetplacement!=''){
	$query = "INSERT INTO widgets (placement, widgetcontent, widgetname) VALUES ('$widgetplacement','$widgetcontent','$widgetname')";
	if(mysqli_query($conn,$query)){
		//echo "widget Added Successfully!";
				$response_array['status'] = 'success';
			    header('Content-type: application/json');
           		echo json_encode($response_array);
			    
	}else{
		//echo "Widget Addition Failure!";
		//check if already exists
			//$id = mysqli_insert_id($conn);
			$queryUpdater = "UPDATE widgets SET placement = '$widgetplacement', widgetcontent = '$widgetcontent', widgetname = '$widgetname' WHERE widgetname = '$widgetname'";
			if(mysqli_query($conn,$queryUpdater)){
				$response_array['status'] = 'success';
			    header('Content-type: application/json');
           		echo json_encode($response_array);
			}
			else{
				$response_array['status'] = 'error';
			    header('Content-type: application/json');
           		echo json_encode($response_array);
			    die(); 
			}
			
	}

}

mysqli_close($conn);


?>