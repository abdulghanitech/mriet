<?php session_start(); 
if (!$_SESSION['username'])  
{  
    header('location: index.php');  
    exit;  
}
?>

<?php include "admin-header.php"; ?>

<?php include "admin-sidebar.php"; ?>
  
   <script>
    $("#sidebar-dashboard").addClass("active");
  </script>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Your Page Content Here -->
      <!-- general stats start here -->

      <div class="row">
        <div class="box box-info box-solid ">
            <div class="box-header with-border">
              <h3 class="box-title">General Stats</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="display: block;">
              <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <?php 

                //setting root
                //
                include "../database.php";

                $sql = "SELECT COUNT(DISTINCT name) from users";

                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){ 

                $row = mysqli_fetch_assoc($result);

                $totalusers = $row["COUNT(DISTINCT name)"];

                echo "<h3>$totalusers</h3>";

              }
              mysqli_close($conn);

              ?>
              <!--<h3>150</h3> -->

              <p>Total Users</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-stalker"></i>
            </div>
            <a href="#" class="custom-dashboard-box-footer small-box-footer"></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">

              <?php 
                //setting root
                //
                include "../database.php";

                $sql2 = "SELECT COUNT(appurl) from basicappdetails";

                $result2 = mysqli_query($conn,$sql2);
                if(mysqli_num_rows($result2) > 0){ 

                $row = mysqli_fetch_assoc($result2);

                $totalapps = $row["COUNT(appurl)"];

                echo "<h3>$totalapps</h3>";

              }
              mysqli_close($conn);


              ?>

              <!--<h3>53<sup style="font-size: 20px">%</sup></h3>-->

              <p>Total Apps</p>
            </div>
            <div class="icon">
              <i class="ion ion-cube"></i>
            </div>
            <a href="#" class="custom-dashboard-box-footer small-box-footer"></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">

              <?php 
                //setting root
                //
                include "../database.php";

                $sql2 = "SELECT COUNT(image) from users";

                $result2 = mysqli_query($conn,$sql2);
                if(mysqli_num_rows($result2) > 0){ 

                $row = mysqli_fetch_assoc($result2);

                $generatedResults = $row["COUNT(image)"];

                echo "<h3>$generatedResults</h3>";

              }
              mysqli_close($conn);


              ?>
              <!--<h3>44</h3>-->

              <p>Generated Results</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="custom-dashboard-box-footer small-box-footer"></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">

              <?php 
                //setting root
                //
                include "../database.php";

                $sql2 = "SELECT COUNT(DISTINCT image) from users";

                $result2 = mysqli_query($conn,$sql2);
                if(mysqli_num_rows($result2) > 0){ 

                $row = mysqli_fetch_assoc($result2);

                $totalShares = $row["COUNT(DISTINCT image)"];

                echo "<h3>$totalShares</h3>";

              }
              mysqli_close($conn);


              ?>
              <!--<h3>65</h3>-->

              <p>Total Shares</p>
            </div>
            <div class="icon">
              <i class="ion ion-android-share-alt"></i>
            </div>
            <a href="#" class="custom-dashboard-box-footer small-box-footer"></a>
          </div>
        </div>
        <!-- ./col -->

            </div>
            <!-- /.box-body -->
          </div>


        
      </div>


      <!-- /.row -->
       <!-- general stats ends here -->

       

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include "admin-footer.php"; ?>
