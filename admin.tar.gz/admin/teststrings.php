<?php
//string

/*$string = "hi there? < >'";

echo "<br>".$string; //echoes normal string

$htmlencodedstring = htmlspecialchars("<>");

echo "<br>".$htmlencodedstring;

$htmlentity = htmlentities($string);

echo "<br>".$htmlentity;
*/
define('CHARSET', 'ISO-8859-1');
define('REPLACE_FLAGS', ENT_COMPAT | ENT_XHTML);


//echo htmlentities('<Il était une fois un être>.', ENT_COMPAT,'ISO-8859-1', true);
// Output: &lt;Il &eacute;tait une fois un &ecirc;tre&gt;.
//                ^^^^^^^^                 ^^^^^^^
header('Content-Type: text/plain');
echo htmlspecialchars('?<>"', ENT_QUOTES,'ISO-8859-1', true);
// Output: &lt;Il était une fois un être&gt;.

function html($string) {
    return htmlspecialchars($string, REPLACE_FLAGS, CHARSET, true);
}

//echo html('<Il était une fois un être>.');
?>
