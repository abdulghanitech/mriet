<?php

//Setting root
$root = realpath($_SERVER["DOCUMENT_ROOT"]);
include "../config.php";

//$apptitleSanitized = preg_replace("/[^a-zA-Z0-9.]/", "", $apptitle);

$target_dir = "../test/".$appurl; //if not there create this directory

$target_dir = "../test/".$appurl; //if not there create this directory

if( is_dir($target_dir) === false )
{
    mkdir($target_dir);

    $target_dir = "../test/".$appurl."/intro";

    	if( is_dir($target_dir) === false){
    		mkdir($target_dir);
    	}

}

$target_dir = "../test/".$appurl."/intro/";

//needs to fixed.. it should create a folder in the same directory with an intro folder too


$target_file = $target_dir . basename($_FILES["file"]["name"]);
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
$uploadOk = 1;

    if ( 0 < $_FILES['file']['error'] ) {
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';
    }
    else {
    	// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
			    //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				//$response_array['status'] = 'FileTypeError';  
			    $uploadOk = 0;
			}

			// Check if file already exists
			if (file_exists($target_file)) {
				$randomizer = rand(1,100000);
				$target_file = $target_dir . $randomizer . $_FILES["file"]["name"];
			    //echo "Sorry, file already exists, changing file name";
			    //$uploadOk = 0;
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			    $response_array['status'] = 'FileUploadError';
			    header('Content-type: application/json');
           		echo json_encode($response_array);
			    die(); 
			    $imageurl = "";
			// if everything is ok, try to upload file
			} else {
			       if(move_uploaded_file($_FILES['file']['tmp_name'], $target_file)){
			        $imageurl = $SITEURL."/test/".$appurl."/intro/". $_FILES['file']['name']; 
			    	}
    			}
    	
    		
    	
    }

?>