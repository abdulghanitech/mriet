<?php

//Setting root
$root = realpath($_SERVER["DOCUMENT_ROOT"]);
include "../config.php";
//include database
include "../database.php";

// Fetching Values From AJAX

$widget_id = $_POST["widget_id"];
$widgetname = $_POST["widgetname"];
$widgetplacement = $_POST["widgetplacement"];
$widgetcontent = $_POST["widgetcontent"];
//base64 encoding widget content
$widgetcontent = base64_encode($widgetcontent);


if($widget_id!=''){
	$query = "UPDATE widgets SET widgetname = '$widgetname', placement = '$widgetplacement', widgetcontent = '$widgetcontent' WHERE widget_id = '$widget_id'";
	if(mysqli_query($conn,$query)){
		
		$response_array['status'] = 'success';
		header('Content-type: application/json');
        echo json_encode($response_array);
  
	}else {
		//echo "<br>ERROR: Could not able to execute $query. " . mysqli_error($conn);
		//echo "\nPlease Select an App to Delete";
		 $response_array['status'] = 'error';
		 header('Content-type: application/json');
		 echo json_encode($response_array);

		//die();
	}
}


?>