<?php
//Setting root
$root = realpath($_SERVER["DOCUMENT_ROOT"]);
include "../database.php";

$fbappid = $_POST["fbappid"];
$fbappsecret = $_POST["fbappsecret"];


if($fbappid!=''&&$fbappsecret!=''){
	$query = "UPDATE fbconfig SET fbappid = '$fbappid', fbappsecret = '$fbappsecret' WHERE id = '0'";

	if(mysqli_query($conn, $query)){
		$response_array['status'] = 'success';
		header('Content-type: pagelication/json');
        echo json_encode($response_array);
	}
	else{
		$response_array['status'] = 'error';
		header('Content-type: pagelication/json');
        echo json_encode($response_array);
	}
}

?>