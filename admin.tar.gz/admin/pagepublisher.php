<?php
//Publishing the pages
//Setting root
$root = realpath($_SERVER["DOCUMENT_ROOT"]);
include "../database.php";

$pageurl = mysqli_real_escape_string($conn, $_POST["pageurl"]);

//echo "in the pagepublisher file\n";
//echo $pageurl;

if($pageurl!=''){
	$query = "UPDATE pages SET published_status = 'YES' WHERE pageurl = '$pageurl'";
	if(mysqli_query($conn,$query)){
				//page updated successfully
				$response_array['status'] = 'success';
			    header('Content-type: application/json');
           		echo json_encode($response_array);
			    
	}else{
		//echo "Page updation Failure!";
				$response_array['status'] = 'error';
			    header('Content-type: application/json');
           		echo json_encode($response_array);
			    die(); 
			
	}

}

mysqli_close($conn);


?>