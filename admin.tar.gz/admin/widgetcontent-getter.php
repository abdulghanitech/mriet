<?php

//Setting root
$root = realpath($_SERVER["DOCUMENT_ROOT"]);
include "../config.php";
//include database
include "../database.php";

// Fetching Values From AJAX

$widget_id = $_POST["widget_id"];


//echo "in the appdeleter file\n";
//echo "apptitle = ".$apptitle;

//echo '<script>$("#appdeleteYes").remove();</script>';
//echo "appurl = ".$appurl;


if($widget_id!=''){
	$query = "SELECT widgetcontent FROM widgets WHERE widget_id = '$widget_id'";
	if($result = mysqli_query($conn,$query)){
		$row = mysqli_fetch_assoc($result);
		$widgetcontent = $row["widgetcontent"];
		$widgetcontent = base64_decode($widgetcontent);
		echo $widgetcontent;

  
	}else {
		//echo "<br>ERROR: Could not able to execute $query. " . mysqli_error($conn);
		//echo "\nPlease Select an App to Delete";
		 $response_array['status'] = 'error';
		 header('Content-type: application/json');
		 echo json_encode($response_array);

		//die();
	}
}


?>