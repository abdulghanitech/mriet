<?php

//Setting root
$root = realpath($_SERVER["DOCUMENT_ROOT"]);
include "../config.php";

//echo "appurl: ".$appurl;
//$apptitleSanitized = preg_replace("/[^a-zA-Z0-9.]/", "", $apptitle);

$target_dir = "../test/".$appurl; //if not there create this directory


		//checking base directory with title name created or not
		if( is_dir($target_dir) === false )
		{
		    // Remove any characters you don't want
			// The below code will remove anything that is not a-z, 0-9 or a dot.
			// here we should sanitize the apptitle and not the whole directory
			// that's why we have given apptitle as param to preg_replace over here
		    mkdir($target_dir);

		}
		//making background directory
		$target_dir = "../test/".$appurl."/background";

    	if( is_dir($target_dir) === false){
  
		    mkdir($target_dir);
    	}

$target_dir = "../test/".$appurl."/background/";
//$target_dir = preg_replace("/[^a-zA-Z0-9.]/", "", $target_dir);

$target_file = $target_dir . basename($_FILES["file"]["name"]);
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
$uploadOk = 1;

    if ( 0 < $_FILES['file']['error'] ) {
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';
    }
    else {
    	// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
			    //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";	
			    $uploadOk = 0;
			}

			// Check if file already exists
			if (file_exists($target_file)) {
				$randomizer = rand(1,100000);
				$target_file = $target_dir . $randomizer . $_FILES["file"]["name"];
			    //echo "File already exists, changing file name";
			    //$uploadOk = 0;
			}

			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
			    //echo "Sorry, your file was not uploaded.";
			    $backgroundimageurl = "";
			    $response_array['status'] = 'FileUploadError';
			    header('Content-type: application/json');
           		echo json_encode($response_array);
			    die();  
			// if everything is ok, try to upload file
			} else {
			       if(move_uploaded_file($_FILES['file']['tmp_name'], $target_file)){
			        $backgroundimageurl = $SITEURL."/test/".$appurl."/background/". $_FILES['file']['name']; 
			        $backgroundimageurl = str_replace(' ', '%20', $backgroundimageurl);
			    	}
    			}
    	
    		
    	
    }

?>