<?php

//Setting root
$root = realpath($_SERVER["DOCUMENT_ROOT"]);
include "$root/config.php";
//include database
include "$root/database.php";

// Fetching Values From AJAX

$pageurl = $_POST["pageurl"];

//echo "in the pagecontent-getter";
//echo "pageurl: ".$pageurl;

if(isset($pageurl)){
	$query = "SELECT pagecontent FROM pages WHERE pageurl = '$pageurl'";
	$result = mysqli_query($conn,$query);
	if($result){
		//echo "Deleted page : ".$pagetitle;
		//echo '<script>$("#pagedeleteYes").remove();</script>';
		$row = mysqli_fetch_assoc($result);
		echo $row["pagecontent"];
		/*$response_array['status'] = 'success';
		header('Content-type: pagelication/json');
        echo json_encode($response_array);*/
  
	}else {
		//echo "<br>ERROR: Could not able to execute $query. " . mysqli_error($conn);
		//echo "\nPlease Select an page to Delete";
		 $response_array['status'] = 'error';
		 header('Content-type: pagelication/json');
		 echo json_encode($response_array);

		//die();
	}
}


?>