<?php session_start(); 
if (!$_SESSION['username'])  
{  
    header('location: index.php');  
    exit;  
}
?>

<?php include "admin-header.php"; ?>

<?php 
//Setting root
$root = realpath($_SERVER["DOCUMENT_ROOT"]);
include "admin-sidebar.php";
include "../config.php";
 ?>
   <script>
    $("#sidebar-widgets").addClass("active");
  </script>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Widgets
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Add New Widget</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-8">
          <div class="box box-warning box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">New Widget</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="form-group">
                <label for="widgetName">Widget Name:</label>
                <input type="text" class="form-control" name="widgetName" id="widgetName" placeholder="title or name of the widget">
              </div>
              <div class="form-group">
                  <label for="widgetPlacement">Select Placement:</label>
                  <select class="form-control" id="widgetPlacement" name="widgetPlacement">
                    <option value="sidebar">Sidebar</option>
                    <option value="header">Header</option>
                    <option value="footer">Footer</option>
                    <option value="above the app">Above the App</option>
                    <option value="below the app">Below the App</option>
                  </select>
                </div>
              <div class="form-group">
                <label for="widgetContent">Widget Content:</label>
                <textarea class="form-control" rows="4" id="widgetContent" name="widgetContent" placeholder="Insert the code/text here" required></textarea>
              </div>
              <button class="btn btn-primary" onclick="saveWidget()">Save</button>
              <img id="widgetProcess">
              <p id="widgetResultSuccess" style="color: green;"></p>
              <p id="widgetResultError" style="color: red;"></p>
            </div>
            <!-- /.box-body -->
          </div>
        </div>
      </div>


    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php include "admin-footer.php"; ?>
